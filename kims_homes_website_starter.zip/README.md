# Kims Homes — website with customer and admin login

This is a mobile-friendly real-estate website starter for Kims Homes. It includes:
- Public property listing page and search filters
- Email/password customer sign-up and login using Firebase Authentication
- Customer inquiry form saved to Firestore
- Admin dashboard to add/delete listings and review inquiries
- Firestore rules that reserve property management for approved admin accounts

## Important
The site is not live or connected to a database until you complete the setup below. The house photos are remote demo images. Replace demo content and imagery with material you have permission to use. Do not publish fake property prices or contact details.

## Part A — Create a free Firebase project (phone browser)

1. Open https://console.firebase.google.com/ in Chrome and sign in with Google.
2. Tap **Create a project** and name it `kims-homes` (or another available project ID). You can disable Analytics to keep setup simple.
3. In the project overview, tap the web icon `</>` to add a web app. Name it `Kims Homes Website`. Register it.
4. Firebase shows a `firebaseConfig` object. Copy the values into the matching fields in `index.html`, replacing:
   - `PASTE_API_KEY_HERE`
   - `PASTE_PROJECT_ID_HERE`
   - `PASTE_MESSAGING_SENDER_ID_HERE`
   - `PASTE_APP_ID_HERE`
   The auth domain should be `YOUR_PROJECT_ID.firebaseapp.com`; storage bucket should match the value Firebase gives you. The app does not use Firebase Storage for uploads yet.
5. In Firebase Console, open **Authentication → Get started → Sign-in method**, enable **Email/Password**, and save.
6. Open **Firestore Database → Create database**. Start in production mode and choose a nearby region if available. Create the database.

## Part B — Add the database security rules

1. In Firebase Console, open **Firestore Database → Rules**.
2. Replace the rules there with the contents of `firestore.rules`.
3. Tap **Publish**.

These rules are important. Do not skip them. Only an admin document created by you in Firebase Console can grant admin privileges.

## Part C — Publish the website free with GitHub Pages (phone)

1. Open https://github.com and create a free account or log in.
2. Create a new **public** repository named `kims-homes-website`.
3. Upload `index.html` and `firestore.rules` from this ZIP. Also upload `README.md` if you want setup notes available in the repository.
4. In the repository, open **Settings → Pages**.
5. Under Build and deployment, select **Deploy from a branch**; choose `main` and `/(root)`, then Save.
6. Wait a few minutes. GitHub will show the website address, usually `https://YOUR-USERNAME.github.io/kims-homes-website/`.
7. Copy that exact address. In Firebase Console go to **Authentication → Settings → Authorized domains** and add the GitHub Pages hostname, for example `YOUR-USERNAME.github.io` (host only; no `https://` or path).

GitHub Pages serves the front end for free. Firebase has a free usage tier, but quotas and product terms can change. A custom `.com` domain is not included for free.

## Part D — Create your first customer account, then make it admin

1. Open your published website and create an account using your email and a strong password.
2. In Firebase Console, open **Authentication → Users** and find the account you just created. Copy its **User UID** exactly.
3. Open **Firestore Database → Data**. Create a collection named `admins` if needed.
4. Add a document whose **Document ID** is the exact User UID from step 2. You may add a field `createdAt` of type string with value `owner` (the document's existence is what grants admin access).
5. Refresh the website and log in again. The top button should show **Admin account** and the Owner dashboard should appear.

Never create admin documents for customers. Do not let the public website create or edit the `admins` collection. The provided rules deny client-side writes.

## Part E — Test it

- Open the site in a private/incognito tab and create a separate test customer account.
- Check that customer can sign up and log in but does not see the Owner dashboard.
- As admin, add a test property and confirm it appears in Featured Properties.
- Submit a test inquiry. As admin, check it appears under Customer inquiries.
- Delete your test property and test inquiry if no longer needed.

## Limitations and next improvements

- The admin dashboard currently adds listings using image URLs; it does not upload image files directly. For a zero-budget first version, upload photos to a reputable image host you control and use the direct public image URL, or add Firebase Storage later after reviewing its current billing/plan requirements.
- Email/password authentication is included; email verification and password-reset UI are not yet included. Add them before using this for a larger customer base.
- This starter is not a complete property transaction platform and does not process payments.
- Protect the Firebase project owner account with a strong unique password and two-step verification. Never share your Firebase console password or private credentials.
- The Firebase web API key is intended to be present in a browser app; security depends on Authentication, Firestore rules, and authorized domains—not on hiding that key.
